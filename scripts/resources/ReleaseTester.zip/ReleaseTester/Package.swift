// swift-tools-version:5.5

import PackageDescription

let package = Package(
    name: "ReleaseTester",
    platforms: [.iOS(.v10)],
    products: [
        .library(
            name: "ReleaseTester",
            targets: ["ReleaseTester"]),
    ],
    dependencies: [
        .package(path: "PATH_TO_HEAP")
    ],
    targets: [
        .target(
            name: "ReleaseTester",
            dependencies: [
                .product(name: "Heap", package: "heap-ios-sdk")
            ]),
    ]
)

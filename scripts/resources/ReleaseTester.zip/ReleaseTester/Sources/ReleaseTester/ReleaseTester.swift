import Heap

public struct ReleaseTester {
    public init() {
        let options = HeapOptions()
        options.debug = true
        Heap.initialize("11", with: options)
    }
}
